@extends('front-layout/app')
@section('title','Berita | Demak Tanggap Covid-19')
@section('content')
    <!-- berita -->
    <section id="berita">
      <div class="container">
        <header class="section-header">
          <!-- <h4>Kabar Covid-19 Di Kab. Demak</h4> -->
          <br><hr>
        </header>
        <div class="row mbb">
            <div class="card col-md-9 imgbg">
            <h3 class="fonttitle" >
                <b>Berita Seuptar Covid-19 Kab. Demak</b>
            </h3>
            <hr>
            <div class="row">
              <!-- sampel 1-->
                    <div class="col-md-4">
                        <br>
                        <div class="card shadow-sm">
                            <a href="/"><img src="{{asset('corona-template/img/intro-img.svg')}}" class="card-img-top imgpost rounded"
                                    alt="..."></a>
                            <div class="card-body1 cardpost fontstyle">
                                <h6 class="card-title titlepost"><a class="colortitle" href="/" ><b>judul</b></a></h6>
                                <hr>
                                <p class="card-text">isi konten
                                </p>
                                <a href="/" class="btn btn-outline-info btn-sm">Baca Selengkapnya</a>
                                <br>
                                <small class="text-muted">tanggal</small>
                            </div>
                        </div>
                    </div>
              <!-- 2 -->
                    <div class="col-md-4">
                        <br>
                        <div class="card shadow-sm">
                            <a href="/"><img src="{{asset('corona-template/img/intro-img.svg')}}" class="card-img-top imgpost rounded"
                                    alt="..."></a>
                            <div class="card-body1 cardpost fontstyle">
                                <h6 class="card-title titlepost"><a class="colortitle" href="/" ><b>judul</b></a></h6>
                                <hr>
                                <p class="card-text">isi konten
                                </p>
                                <a href="/" class="btn btn-outline-info btn-sm">Baca Selengkapnya</a>
                                <br>
                                <small class="text-muted">tanggal</small>
                            </div>
                        </div>
                    </div>
              <!-- 3 -->
                    <div class="col-md-4">
                        <br>
                        <div class="card shadow-sm">
                            <a href="/"><img src="{{asset('corona-template/img/intro-img.svg')}}" class="card-img-top imgpost rounded"
                                    alt="..."></a>
                            <div class="card-body1 cardpost fontstyle">
                                <h6 class="card-title titlepost"><a class="colortitle" href="/" ><b>judul</b></a></h6>
                                <hr>
                                <p class="card-text">isi konten
                                </p>
                                <a href="/" class="btn btn-outline-info btn-sm">Baca Selengkapnya</a>
                                <br>
                                <small class="text-muted">tanggal</small>
                            </div>
                        </div>
                    </div>
            </div>
            <br>
        </div>
         
        <!-- row bagian hotline kanan -->
            <div class="col-md-3 card-margin">
                <div class="row">
                    <div class="col-md-12">
                        {{-- hotline slider --}}
                         @include('front-layout/slider-info-hotline')
                         {{-- end hotline --}}
                         <br>
                        <div class="card shadow-sm imgbg rounded"> 
                          <div class="btn btn-secondary btn-sm">Kategori Berita</div>
                            <div class="row">
                                <div class="col-md-6">
                                    <a class="col-md-12 btn btn-outline-primary btn-sm"
                                        href="/">Demak</a>
                                </div>
                                <div class="col-md-6">
                                    <a class="col-md-12 btn btn-outline-primary btn-sm"
                                        href="/artikel-kategori/loker-jawa-tengah">Semarang</a>
                                </div>
                            </div>  
                        </div>
                        <br>
                        <div class="card shadow-sm imgbg rounded">
                           <div class="btn btn-info btn-sm">Tag Berita </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <a class="col-md-12 btn btn-outline-primary btn-sm"
                                        href="/">Demak</a>
                                </div>
                                <div class="col-md-6">
                                    <a class="col-md-12 btn btn-outline-primary btn-sm"
                                        href="/artikel-kategori/loker-jawa-tengah">Semarang</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
          <!-- end row -->
        </div>
      </div>
    </section>
    <!-- end berita -->
@endsection