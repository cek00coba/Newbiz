@extends('front-layout/app')
@section('title','Kontak | Demak Tanggap Covid-19')
@section('content')
    {{-- kontak --}}
         <section id="berita">
      <div class="container">
        <header class="section-header">
          <!-- <h4>Kabar Covid-19 Di Kab. Demak</h4> -->
          <br><hr>
        </header>
        <div class="row mbb">
            <div class="card col-md-8 imgbg rounded">
                <!-- <h3 class="fonttitle" >
                    <b>Hotline Covid-19 Kabupaten Demak</b>
                </h3> -->
                
                  <div class="card shadow-sm imgbg rounded">
                           <div class="btn btn-danger"><img src="{{asset('corona-template/img/datacovid/call.jpeg')}}" class="card-img-top"
                                    ></div> 
                  </div>
                
            </div>
         <!-- row bagian hotline kanan -->
         
            @include('front-layout/slider-hotline')
          <!-- end row -->
        </div>
      </div>
    </section>
    {{-- end kontak --}}
@endsection