@extends('front-layout/app')
@section('title','Demak Tanggap Covid-19')
@section('intro-header')
  @include('front-layout/intro-header')
@endsection

@section('content')
    <main id="main">
            <!-- berita -->
            @include('front-layout/berita')
            <!-- end berita -->

            {{-- aout data covid --}}
            @include('front-layout/about-covid')
            {{-- end data covid --}}
            
            {{-- slider data covid --}}
            @include('front-layout/slider-data-covid')
            {{-- end slider data covid --}}
            
            <!-- status data vaksinasi  -->
            @include('front-layout/data-vaksin')
            <!-- end status vaksin -->

            <!-- data pelaksanaan  -->
            @include('front-layout/data-swab')
            <!-- end data pelaksanaan covid -->

            <!-- faq covid 19 -->
            @include('front-layout/faq-covid')
            
            <!-- end faq covid 19 -->
  </main>
@endsection