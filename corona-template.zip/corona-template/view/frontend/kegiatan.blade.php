@extends('front-layout/app')
@section('title','Kegiatan | Demak Tanggap Covid-19')
@section('content')
    <!-- foto kegiatan berita -->
    <section id="berita">
      <div class="container">
        <header class="section-header">
          <!-- <h4>Kabar Covid-19 Di Kab. Demak</h4> -->
          <br><hr>
        </header>
        <div class="row mbb">
            <div class="card col-md-8 imgbg rounded">
                <h3 class="fonttitle" >
                    <b>Galeri Foto</b>
                </h3>
                
                  <div class="card shadow-sm imgbg rounded">
                           <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                              <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                            </ol>
                            <br>
                            <div class="carousel-inner">
                              <div class="carousel-item active">
                                <img src="{{ asset('corona-template/img/datacovid/kegiatan.jpeg') }}" class="d-block w-100" style="height: 400px;" alt="...">
                              </div>
                              <div class="carousel-item">
                                <img src="{{ asset('corona-template/img/datacovid/kegiatan2.jpeg') }}" class="d-block w-100" style="height: 400px;" alt="...">
                              </div>
                              <div class="carousel-item">
                                <img src="{{ asset('corona-template/img/datacovid/kegiatan3.jpeg') }}" class="d-block w-100" style="height: 400px;"alt="...">
                              </div>
                            </div>
                            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                              <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                              <span class="carousel-control-next-icon" aria-hidden="true"></span>
                              <span class="sr-only">Next</span>
                            </a>
                          </div>
                  </div>
                  <div class="card shadow-sm imgbg rounded">
                        <section>
                        <div id="carouselExampleIndicators2" class=" card carousel slide" data-ride="carousel">
                          <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators2" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleIndicators2" data-slide-to="1"></li>
                            <li data-target="#carouselExampleIndicators2" data-slide-to="2"></li>
                          </ol>
                          <div class="carousel-inner">
                          <div class="card col-md-12 imgbg">
                            
                                <div class="carousel-item active">
                                  <!-- loping  -->
                                  <div class="row">
                                    <div class="col-md-4">
                                      <img src="{{ asset('corona-template/img/datacovid/kegiatan.jpeg') }}" class="d-block w-100 heightslider" alt="...">
                                    </div>
                                    <div class="col-md-4">
                                      <img src="{{ asset('corona-template/img/datacovid/kegiatan2.jpeg') }}" class="d-block w-100 heightslider" alt="...">
                                    </div>
                                    <div class="col-md-4">
                                      <img src="{{ asset('corona-template/img/datacovid/kegiatan3.jpeg') }}" class="d-block w-100 heightslider" alt="...">
                                    </div>
                                  </div>
                                </div>

                              
                          </div>
                          </div>
                        </div>

                        
                      </section>
                  </div>
                
            </div>
            <!-- row bagian hotline kanan -->
            @include('front-layout/slider-hotline')
          <!-- end row -->
        </div>
      </div>
    </section>
    <!-- fend foto kegiatan erita -->

    <!-- fGaleri Video -->
    <section id="faq" class="wow fadeInUp my-2 bgcolor-data">
      <div class="container">
        <header class="section-header">
          <h4>Galeri <span>Video</span></h4>
          <p>Video Kegiatan Tanggap Covid-19 </p>
        </header>
    </section>
    <!-- end galeri video -->
@endsection