@extends('front-layout/app')
@section('title','Regulasi | Demak Tanggap Covid-19')
@section('content')
    <section class="my-2 pd-top">
    <div class="container table-responsive">
      <header class="section-header">
        <h4>Regulasi Covid-19</h4>
      </header>
      <table id="regulasi" class="table table-striped color-table" style="width:100%">
        <thead>
          <tr class="table-primary">
              <th style="width: 5px;">No</th>
              <th>Nama Regulasi</th>
              <th style="width: 10px;">Data</th>
          </tr>
      </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>Protokol-Kesehatan-COVID-19</td>
                <td><a href="#">Download</a></td>
            </tr>
            <tr>
                <td>2</td>
                <td>SE-Panduan-dalam-menangani-COVID-19</td>
                <td><a href="#">Download</a></td>
            </tr>
        </tbody>
      </table>
    </div>
  </section>
@endsection