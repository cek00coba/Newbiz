@extends('front-layout/app')
@section('title','Api | Demak Tanggap Covid-19')
@section('content')
    
@endsection