
<footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-5 col-md-6 footer-info">
            <h4>Demak <br> Tanggap Covid-19</h4>
            <p>Portal website seputar informasi tentang covid-19 yang berada di kabupaten demak</p>
          </div>

          <div class="col-lg-4 col-md-6 footer-links">
            <h4>Link terkait</h4>
            <ul>
              <li><a href="https://demakkab.go.id/" target="blank">demakkab.go.id</a></li>
              <li><a href="https://corona.demakkab.go.id/" target="blank">corona.demakkab.go.id</a></li>
              <li><a href="https://mipp.demakkab.go.id/" target="blank">mipp.demakkab.go.id</a></li>
              <li><a href="https://dinkominfo.demakkab.go.id/" target="blank">dinkominfo.demakkab.go.id</a></li>
            </ul>
          </div>
          
          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Hotline Covid-19 Kab.Demak</h4>
            <p>
              Jl. Sultan Hadiwijaya <br>
              No. 4 Demak 59515<br>
              Kabupaten Demak <br>
              <strong>Phone1:</strong> (0291) 6912119<br>
              <strong>Phone2:</strong> 0812 1001 6119<br>
            </p>

            <div class="social-links">
              <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
              <a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
              <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
            </div>

          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>Dinkominfo</strong>. All Rights Reserved
      </div>
      <div class="credits">
      </div>
    </div>
  </footer>