 <!-- header -->
  <header id="header" class="fixed-top">
    <div class="container">
      <div class="logo float-left">
        <a href="#intro" class="scrollto"> <img src="img/logo/demak-logo.png" alt="" class="img-fluid"> <b>Demak Tanggap Covid-19</b> </a>
       </div>
       <!-- main nav -->
      <nav class="main-nav float-right d-none d-lg-block">
        <ul>
          <li class="active"><a href="/">Home</a></li>
          <li><a href="/berita">Berita</a></li>
          <li><a href="/kegiatan">Kegiatan</a></li>
          <li><a href="/regulasi">Regulasi</a></li>
          <li><a href="/api">Api</a></li>
          <li><a href="/kontak">Kontak</a></li>
        </ul>
      </nav>
      <!-- main-nav -->
      
    </div>
  </header>
  <!-- #header -->