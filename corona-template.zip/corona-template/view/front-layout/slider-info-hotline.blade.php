 <div class="card shadow-sm imgbg rounded">
     <!-- <a href="#" class="btn btn-danger"><img src="img/datacovid/call.jpeg" class="card-img-top"
                                    alt="..."></a>  -->
     <div id="carouselExampleIndicators1" class="carousel slide" data-ride="carousel">
         <ol class="carousel-indicators">
             <li data-target="#carouselExampleIndicators1" data-slide-to="0" class="active"></li>
             <li data-target="#carouselExampleIndicators1" data-slide-to="1"></li>
         </ol>
         <div class="carousel-inner">
             <div class="carousel-item active">
                 <img src="{{ asset('corona-template/img/datacovid/call.jpeg') }}" class="d-block w-100 heightslider2"
                     alt="...">
             </div>
             <div class="carousel-item">
                 <img src="{{ asset('corona-template/img/datacovid/info.jpeg') }}" class="d-block w-100 heightslider2"
                     alt="...">
             </div>
         </div>

     </div>
 </div>
