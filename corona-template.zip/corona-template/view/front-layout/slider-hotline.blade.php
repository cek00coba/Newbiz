<div class="col-md-4 card-margin">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow-sm imgbg rounded">
                          <div class="btn btn-info btn-sm">Hotline Covid-19 Kab. Demak </div>
                        </div>
                        <!-- slider info hotline img -->
                          @include('front-layout/slider-info-hotline')
                        <!-- end slider img -->

                          <!-- call center psc  -->
                          <div class="card card-margin shadow-sm imgbg rounded">
                            <div class="card shadow-sm imgbg rounded">
                               <div class="btn btn-danger btn-sm">DES PSC - 119 Demak </div>
                            </div>
                            <div class="card shadow-sm imgbg rounded">  
                                <a href="tel:02916912119" class="btn btn-outline-danger"><i class="fa fa-phone-square" aria-hidden="true"></i> (0291) 6912119</a>      
                            </div>
                            <div class="card shadow-sm imgbg rounded">  
                                <a href="tel:081210016119" class="btn btn-outline-danger"><i class="fa fa-phone-square" aria-hidden="true"></i> 081210016119</a>      
                            </div>
                          </div>
                          <!-- end call center psc -->

                          <!-- cal center 112 -->
                          <div class="card card-margin shadow-sm imgbg rounded">
                            <div class="card shadow-sm imgbg rounded">
                              <a href="tel:112" class="btn btn-outline-info btn-sm"> Call Center Kab. Demak <br> <i class="fa fa-phone-square" aria-hidden="true"></i> <b>112</b> </a>
                            </div>  
                          </div>
                          <!-- end call center 112 -->
                          <!-- call wa -->
                          <div class="card card-margin shadow-sm imgbg rounded">
                            <div class="card shadow-sm imgbg rounded">
                              <div class="btn btn-success btn-sm"> Layanan Call WhatsApp <i class="fa fa-whatsapp" aria-hidden="true"></i></div>
                            </div>
                            <div class="card shadow-sm imgbg rounded">  
                                <a target="blank" href="https://api.whatsapp.com/send?phone=6281228006700&amp;text=%2A%20Pusat Tanggap Covid-19%20 Kab.Demak - Ada Yang Bisa Kami Bantu ?" class="btn btn-outline-success"><i class="fa fa-whatsapp" aria-hidden="true"></i> 081228006700</a>      
                            </div>
                            <div class="card shadow-sm imgbg rounded">  
                                <a target="blank" href="https://api.whatsapp.com/send?phone=6281228006700&amp;text=%2A%20Pusat Tanggap Covid-19%20 Kab.Demak - Ada Yang Bisa Kami Bantu ?" class="btn btn-outline-success"><i class="fa fa-whatsapp" aria-hidden="true"></i> 08122572416</a>      
                            </div>
                          </div>
                          <!-- end call wa -->   
                      
                    </div>
                </div>

            </div>