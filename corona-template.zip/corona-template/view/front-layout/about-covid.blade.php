<section id="about">
      <div class="container">

        <header class="section-header">
          <h4>Monitoring Covid-19 Kabupaten Demak</h4>
          <p>Sumber : Dinkes Kab Demak, Update terakhir : <b>Selasa, 20 Juli 2021 19:23 WIB</b> <br> <span>*data dapat berubah sewaktu-waktu</span></p>
        </header>
        <div class="row mbb">
            <!-- row 1 -->
            <div class="col-md-4 card-margin hovercard">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow-sm wow bounceInUp">
                              <div class="card-header colorcard1 border-success">Data Kontak Erat</div>
                              <div class="card-body text-success">
                                <p class="card-text">Dalam Pemantauan : <br> Selesai Pemantauan : <br> <br><br> <br> </p>
                              </div>
                              <div class="card-footer bg-transparent border-success">Total Kasus : </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- row 2 -->
            <div class="col-md-4 card-margin hovercard">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow-sm wow bounceInUp">
                              <div class="card-header colorcard2 border-success">Data Kasus Suspek</div>
                              <div class="card-body text-success">
                                <p class="card-text">Dalam Pengawasan : <br> Selesai Pengawasan : <br><br><br> <br>  </p>
                              </div>
                              <div class="card-footer bg-transparent border-success">Total Kasus : </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- row 3 -->
            <div class="col-md-4 card-margin hovercard">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card shadow-sm wow bounceInUp">
                              <div class="card-header colorcard3 border-success">Data Kasus Terkonfirmasi</div>
                              <div class="card-body text-success">
                                <p class="card-text">Dirawat di Rs. Demak : <br> Dirawat di luar Rs. Demak : <br> Karantina : <br> Sembuh : <br> Meninggal : </p>
                              </div>
                              <div class="card-footer bg-transparent border-success">Total Kasus : </div>

                        </div>
                    </div>
                </div>
            </div>
            
        </div>
      
       
      </div>
    </section>