<section id="vaksin" class="wow fadeInDown my-2">
      <div class="container">
        <!-- <header class="section-header"> -->
          <!-- <p>Laudem latine persequeris id sed, ex fabulas delectus quo. No vel partiendo abhorreant vituperatoribus.</p> -->
          <h3 class="row justify-content-center">Status Vaksinasi</h3>
        <!-- </header> -->

        <div class="row row-eq-height justify-content-center text-center">

          <div class="col-lg-4 mb-4">
            <div class="card" data-aos="zoom-in" data-aos-delay="100">
              <!-- <i class="fa fa-diamond"></i> -->
              <div class="card-body vaksin1">
                <h5  class="card-title">Vaksinasi-1</h5>
                <h4  class="card-text">189.043</h4>
              </div>
            </div>
          </div>

          <div class="col-lg-4 mb-4">
            <div class="card" data-aos="zoom-in" data-aos-delay="200">
              <!-- <i class="fa fa-language"></i> -->
              <div class="card-body vaksin2">
                <h5 class="card-title">Vaksinasi-2</h5>
                <h4 class="card-text">59.043</h4>
              </div>
            </div>
          </div>

        </div>

      </div>
        <div class="container table-responsive my-2">
            <table class="table table-bordered color-table">
              <tbody>
                <tr class="textcenter colorbg">
                  
                  <th  colspan="1">Tahap</th>
                  <th  colspan="2">Tahap I</th>
                  <th  colspan="4">Tahap II</th>
                  <th  colspan="4">Tahap III</th>
                
                  <!-- <th style="text-align:center;border:1px solid grey" colspan="2">Tahap IV</th> -->
                </tr>
              <tr class="textcenter">
                <th  rowspan="2">Kategori</th>
                <th  colspan="2">SDM KESEHATAN</th>
                <th  colspan="2">LANSIA</th>
                <th  colspan="2">PETUGAS PUBLIK</th>
                <th  colspan="2">MASY RENTAN &amp; UMUM</th>
                <th  colspan="2">REMAJA</th>
              </tr>
              <tr class="textcenter">
                <th>1</th>
                <th>2</th>
                <th>1</th>
                <th>2</th>
                <th>1</th>
                <th>2</th>
                <th>1</th>
                <th>2</th>
                <th>1</th>
                <th>2</th>
              </tr>
                <tr>
                  <td class="textleft">Sudah Divaksin</td>
                  <td class="textcenter-color1">4.285</td>
                  <td class="textcenter-color2">4.099</td>
                  <td class="textcenter-color1">19.927</td>
                  <td class="textcenter-color2">12.487</td>
                  <td class="textcenter-color1">43.054</td>
                  <td class="textcenter-color2">27.766</td>
                  <td class="textcenter-color1">14.656</td>
                  <td class="textcenter-color2">5.619</td>
                  <td class="textcenter-color1">15</td>
                  <td class="textcenter-color2">0</td>
                </tr>
                <tr>
                  <td class="textleft">- Sinovac</td>
                  <td class="textcenter-color1">14</td>
                  <td class="textcenter-color2">5</td>
                  <td class="textcenter-color1">2.935</td>
                  <td class="textcenter-color2">1.057</td>
                  <td class="textcenter-color1">6.760</td>
                  <td class="textcenter-color2">2.625</td>
                  <td class="textcenter-color1">2.984</td>
                  <td class="textcenter-color2">150</td>
                  <td class="textcenter-color1">1</td>
                  <td class="textcenter-color2">0</td>
                </tr>
                  <tr>
                  <td class="textleft">- Astrazeneca</td>
                  <td class="textcenter-color1">0</td>
                  <td class="textcenter-color2">0</td>
                  <td class="textcenter-color1">0</td>
                  <td class="textcenter-color2">0</td>
                  <td class="textcenter-color1">0</td>
                  <td class="textcenter-color2">0</td>
                  <td class="textcenter-color1">0</td>
                  <td class="textcenter-color2">0</td>
                  <td class="textcenter-color1">0</td>
                  <td class="textcenter-color2">0</td>
                </tr>
                  <tr>
                  <td class="textleft">Tunda</td>
                  <td class="textcenter-color1">0</td>
                  <td class="textcenter-color2">0</td>
                  <td class="textcenter-color1">0</td>
                  <td class="textcenter-color2">0</td>
                  <td class="textcenter-color1">0</td>
                  <td class="textcenter-color2">0</td>
                  <td class="textcenter-color1">0</td>
                  <td class="textcenter-color2">0</td>
                  <td class="textcenter-color1">0</td>
                  <td class="textcenter-color2">0</td>
                </tr>
            </tbody></table>
        </div>
    </section>