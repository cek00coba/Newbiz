  <section class="my-3">
      <div class="container table-responsive ">
        <header class="section-header">
          <h4>Data Pelaksanaan Swab<br><span>Kabupaten Demak</span></h4>
          <p>Sumber data : <span style="color: red;"><a target="_BLANK" href="http://allrecord-tc19.kemkes.go.id">allrecord-tc19.kemkes.go.id</a></span></p>
        </header>
          <table id="swab" class="table table-striped table-bordered" style="width:100%;background-color: white;">
            <thead>
                <tr class="text-center colorbg">
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Jumlah Swab Test</th>
                    <th>Terkonfirmasi Positif</th>
                    <th>Kumulatif Swab Test</th>
                </tr>
            </thead>
            <tbody>
                <tr class="textcenter">
                    <td>1</td>
                    <td>19 January 2021</td>
                    <td>87</td>
                    <td>0</td>
                    <td>21.955</td>
                </tr>
                <tr class="textcenter">
                    <td>2</td>
                    <td>18 January 2021</td>
                    <td>106</td>
                    <td>0</td>
                    <td>21.868</td>
                </tr>
            </tbody>
          </table>
      </div>
    </section>