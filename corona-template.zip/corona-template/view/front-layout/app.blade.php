<!DOCTYPE html>
<html lang="en">
{{-- header --}}
@include('front-layout/head')
{{-- end header --}}
<body>
    {{-- Navbar --}}
    @include('front-layout/navbar')
    {{-- end navar --}}

    {{-- header-intro --}}
        @yield('intro-header')
    {{-- end header-intro --}}
  <br>
  @yield('content')
    {{-- footer --}}
      @include('front-layout/footer')
    {{-- end footer --}}

  {{-- button call --}}
  @include('front-layout/button-call')
  {{-- end button call --}}
  {{-- java script --}}
  @include('front-layout/js')
  {{-- end java script --}}
</body>
</html>
