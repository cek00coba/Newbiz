<!-- JavaScript Libraries -->
  <script src="{{asset('corona-template/lib/jquery/jquery.min.js')}}"></script>
  <script src="{{asset('corona-template/lib/jquery/jquery-migrate.min.js')}}"></script>
  <script src="{{asset('corona-template/lib/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('corona-template/lib/easing/easing.min.js')}}"></script>
  <script src="{{asset('corona-template/lib/mobile-nav/mobile-nav.js')}}"></script>
  <script src="{{asset('corona-template/lib/wow/wow.min.js')}}"></script>
  <script src="{{asset('corona-template/lib/waypoints/waypoints.min.js')}}"></script>
  <script src="{{asset('corona-template/lib/counterup/counterup.min.js')}}"></script>
  <script src="{{asset('corona-template/lib/owlcarousel/owl.carousel.min.js')}}"></script>
  <script src="{{asset('corona-template/lib/isotope/isotope.pkgd.min.js')}}"></script>
  <script src="{{asset('corona-template/lib/lightbox/js/lightbox.min.js')}}"></script>
  <!-- Contact Form JavaScript File -->
  <script src="{{asset('corona-template/contactform/contactform.js')}}"></script>

  <!-- Template Main Javascript File -->
  <script src="{{asset('corona-template/js/main.js')}}"></script>

  <!-- Datatables -->
  <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#swab').DataTable();
    } );
  </script>
  <script>
    $(document).ready(function() {
      $('#regulasi').DataTable();
    } );
  </script>