<!-- header intro-->
  <section id="intro" class="clearfix">
    <div class="container">

      <div class="intro-img">
        <img src="{{asset('corona-template/img/logo/covid.png')}}" alt="" class="img-fluid">
      </div>

      <div class="intro-info">
        <h2>Demak Tanggap Covid-19</h2>
        <h5>Pusat Informasi Seputar Covid-19 Di Kabupaten Demak</h5>
        <div>
          <a href="tel:112" class="btn-get-started scrollto">Hotline Covid-19</a>
          <a href="tel:112" class="btn-services scrollto"><i class="fa fa-phone-square" aria-hidden="true"></i> Call Center 112 atau 119</a>
        </div>
      </div>
    </div>
  </section>
  <!-- end header intro -->