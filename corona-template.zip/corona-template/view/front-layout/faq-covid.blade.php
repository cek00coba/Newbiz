<section id="faq" class="bgcolor-data">
      <div class="container">
        <header class="section-header">
          <h4>Frequently Asked Question (FAQ)<br><span>Seputar Covid-19</span></h4>
          <p>Pertanyaan yang sering di tanyakan seputar covid-19</p>
        </header>
        <div class="wow bounceInUp accordion md-accordion" id="accordionEx1" role="tablist" aria-multiselectable="true">
          <div class="card">
            <div class="card-header section-bg" role="tab" id="headingTwo1">
              <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx1" href="#collapseTwo1"
                aria-expanded="false" aria-controls="collapseTwo1">
                <h5 class="mb-0">
                  Apa itu virus corona? <span class="float-right"><i class="fa fa-angle-down rotate-icon"></i></span>
                </h5>
              </a>
            </div>
 
            <!-- Card body -->
            <div id="collapseTwo1" class="collapse" role="tabpanel" aria-labelledby="headingTwo1"
              data-parent="#accordionEx1">
              <div class="card-body">
                Virus korona adalah sebutan untuk jenis virus yang dapat menyebabkan penyakit pada hewan dan manusia. Disebut korona karena bentuknya yang seperti mahkota (korona ~ crown = mahkota dalam bahasa Latin). 
 
                Beberapa contoh penyakit pada manusia yang disebabkan oleh virus korona antara lain MERS (Sindrom Pernafasan Timur Tengah) dan SARS (Sindrom Pernafasan Akut Parah). 
                
                Virus korona terbaru yang ditemukan yang ditemukan di Wuhan, Tiongkok, pada bulan Desember 2019 diberi nama SARS Coronavirus 2 (SARS-CoV-2) dan menyebabkan penyakit Coronavirus Disease 2019 (COVID-19).
                
                Sumber: https://www.who.int/news-room/q-a-detail/q-a-coronaviruses 
              </div>
            </div>
 
          </div>
          <!-- Accordion card -->
 
          <!-- Accordion card -->
          <div class="card">
 
            <!-- Card header -->
            <div class="card-header section-bg" role="tab" id="headingTwo2">
              <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx1" href="#collapseTwo21"
                aria-expanded="false" aria-controls="collapseTwo21">
                <h5 class="mb-0">
                  Bagaimana COVID-19 menular? <span class="float-right"><i class="fa fa-angle-down rotate-icon"></i></span>
                </h5>
              </a>
            </div>
 
            <!-- Card body -->
            <div id="collapseTwo21" class="collapse" role="tabpanel" aria-labelledby="headingTwo21"
              data-parent="#accordionEx1">
              <div class="card-body">
                Penularan terjadi melalui droplet (butir-butir tetesan cairan) dari hidung atau mulut yang menyebar saat pembawa virus COVID-19 batuk, bersin atau meler. Tetesan cairan tersebut akan menempel pada benda atau permukaan di sekitarnya. Dan kemudian masuk ke mulut, hidung atau mata. Atau menyentuh permukaan bekas terkena butir cairannya dengan tangan lalu tangan mengusap mulut, hidung atau mata. Inilah alasan pentingnya sering-sering cuci tangan dan jangan menyentuh muka dengan tangan.
 
                Orang sehat dapat tertular saat tangan mereka menyentuh permukaan yang terkena tetesan tersebut dan kemudian tanpa sadar menyentuh mata, mulut, ataupun hidung (selaput lendir). Virus juga bisa masuk saat orang sehat secara tidak sengaja menghirup tetesan cairan saat si pembawa virus batuk atau bersin.
              </div>
            </div>
 
          </div>
          <!-- Accordion card -->
 
          <!-- Accordion card -->
          <div class="card">
 
            <!-- Card header -->
            <div class="card-header section-bg" role="tab" id="headingThree31">
              <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx1" href="#collapseThree31"
                aria-expanded="false" aria-controls="collapseThree31">
                <h5 class="mb-0">
                  Jika seseorang terinfeksi virus ini, berapa lama sampai muncul gejala? <span class="float-right"><i class="fa fa-angle-down rotate-icon"></i></span>
                </h5>
              </a>
            </div>
 
            <!-- Card body -->
            <div id="collapseThree31" class="collapse" role="tabpanel" aria-labelledby="headingThree31"
              data-parent="#accordionEx1">
              <div class="card-body">
                Masa inkubasi (dari masuknya virus ke dalam tubuh sampai munculnya gejala awal) adalah 1 – 14 hari, dengan rata-rata timbulnya gejala selama 5 hari.
 
                Sumber: https://www.who.int/news-room/q-a-detail/q-a-coronaviruses
              </div>
            </div>
 
          </div>
          <!-- Accordion card -->
 
        </div>
        <!-- Accordion wrapper -->
 
    </section>