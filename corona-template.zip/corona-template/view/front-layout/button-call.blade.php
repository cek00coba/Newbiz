
  <!-- <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a> -->
  <a href="tel:112" class="fixed-bottom1"><img src="{{asset('corona-template/img/logo/callcenter112.png')}}" style="width: 100%"></a>
  <!-- <a href="#" class="back-to-top"><img src="img/logo/call.png" alt=""></a> -->
  <!-- Uncomment below i you want to use a preloader -->
  <!-- <div id="preloader"></div> -->
