<section id="berita">
      <div class="container">
        <header class="section-header">
          <!-- <h4>Kabar Covid-19 Di Kab. Demak</h4> -->
          <p>Kabar Terbaru Seputar Covid-19 Di Area Kabupaten Demak</p>
          <hr>
        </header>
        <div class="row mbb">
            <div class="card col-md-8 imgbg rounded">
                <h3 class="fonttitle" >
                    <b>Breaking News</b>
                </h3>
                <hr>
                
                <div class="row">
                        <!-- sampel berita 1 -->
                        <div class=" col-md-12">
                            <div class="row">
                                <div class="col-md-4">
                                    <a href="#"><img src="{{asset('corona-template/img/intro-img.svg')}}" class="card-img-top imgpost rounded"
                                                    alt="..."></a>
                                </div>
                                <br>
                                <div class="col-md-8">
                                    <div class="">
                                    <h4 class="card-title titlepost"><a class="colortitle" href="#" ><h6><b>Judul Berita</b></h6></a></h4>
                                                <br>
                                                <p class="card-text">isi berita
                                                </p>
                                                
                                                <a href="#" class="btn btn-outline-info btn-sm">Baca Selengkapnya</a>
                                                <br>
                                                <small class="text-muted">tanggal</small>
                                                <hr>
                                    </div>
                                </div> 
                            </div>
                            <br>
                        </div>
                        <!-- end sampel berita 1  -->
                        <!-- sample berita 2  -->
                        <div class=" col-md-12">
                            <div class="row">
                                <div class="col-md-4">
                                    <a href="#"><img src="{{asset('corona-template/img/intro-img.svg')}}" class="card-img-top imgpost rounded"
                                                    alt="..."></a>
                                </div>
                                <br>
                                <div class="col-md-8">
                                    <div class="">
                                    <h4 class="card-title titlepost"><a class="colortitle" href="#" ><h6><b>Judul Berita</b></h6></a></h4>
                                                <br>
                                                <p class="card-text">isi berita
                                                </p>
                                                
                                                <a href="#" class="btn btn-outline-info btn-sm">Baca Selengkapnya</a>
                                                <br>
                                                <small class="text-muted">tanggal</small>
                                                <hr>
                                    </div>
                                </div> 
                            </div>
                            <br>
                        </div>  
                        <!-- end sampel -->
                        <!-- sample  berita3  -->
                        <div class=" col-md-12">
                            <div class="row">
                                <div class="col-md-4">
                                    <a href="#"><img src="{{asset('corona-template/img/intro-img.svg')}}" class="card-img-top imgpost rounded"
                                                    alt="..."></a>
                                </div>
                                <br>
                                <div class="col-md-8">
                                    <div class="">
                                    <h4 class="card-title titlepost"><a class="colortitle" href="#" ><h6><b>Judul Berita</b></h6></a></h4>
                                                <br>
                                                <p class="card-text">isi berita
                                                </p>
                                                
                                                <a href="#" class="btn btn-outline-info btn-sm">Baca Selengkapnya</a>
                                                <br>
                                                <small class="text-muted">tanggal</small>
                                                <hr>
                                    </div>
                                </div> 
                            </div>
                            <br>
                        </div>  
                        <!-- end sample berita 3  -->
                        <br>
                </div>            
                  <a href="#" class="btn btn-outline-secondary btn-sm">Lebih Banyak Berita</a>
                  <hr>
            </div>
          <!-- row bagian hotline kanan -->
            @include('front-layout/slider-hotline')
          <!-- end row -->
        </div>
      </div>
    </section>