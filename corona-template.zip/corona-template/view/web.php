<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FrontendController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// front layout
Route::get('/', [FrontendController::class,'index'])->name('dashboard');
Route::get('/berita', [FrontendController::class,'berita'])->name('berita');
Route::get('/kegiatan', [FrontendController::class,'kegiatan'])->name('kegiatan');
Route::get('/regulasi', [FrontendController::class,'regulasi'])->name('regulasi');
Route::get('/api', [FrontendController::class,'api'])->name('api');
Route::get('/kontak', [FrontendController::class,'kontak'])->name('kontak');
// end front layout

// Route::get('/', function () {
//     return view('welcome');
// });



